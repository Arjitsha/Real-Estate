import React, {useState} from 'react'

import {BsFillHouseFill} from 'react-icons/bs'

import './Navbar.css'

const Navbar = () => {

    const[click, setClick] = useState(false)
    const handleClick = () => setClick(!click)

    return (
        <div className='navbar'>
            <div className='container'>
                <marquee><h1><span><BsFillHouseFill />Real</span>Estate</h1></marquee>&ensp;       
                <ul className={click ? 'nav-menu active' : 'nav-menu'}>
                
                    
                    <li><a href=''>Signout</a></li>
                </ul>
                
             
            </div>
        </div>
    )
}

export default Navbar
