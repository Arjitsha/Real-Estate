import React from 'react'

import {FaFacebook, FaInstagram, FaTwitter, FaPinterest} from 'react-icons/fa'

import './Footer.css'

const Footer = () => {
    return (
        <div className='footer'>
            <div className='social'>
            <a href="https://www.facebook.com"><FaFacebook className='icon' /></a>
     <a href="https://www.Instagram.com.com"><FaInstagram className='icon'/></a>
     <a href="https://www.Twitter.com"><FaTwitter className='icon' /></a>
            </div>
          
        </div>
    )
}

export default Footer