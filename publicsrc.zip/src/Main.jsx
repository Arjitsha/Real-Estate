import  React, {component} from "react";
import Best from './components/best/Best'
import Hero from './components/hero/Hero'
import Navbar from './components/navbar/Navbar'
import Footer from './components/footer/Footer'


export default function Mainpage(props) 
{
  
    return (


    
    
        

        <div> 
            <Navbar>

        </Navbar>
           <Hero></Hero>
           <Best {...props}></Best>
           
            
            
            <Footer></Footer>
        </div>
    

    
        
          );
        
        

}