import React, { Component } from 'react'
import { Card, Col, Row, Select, Carousel,  } from 'antd';
import { city, RealEstateData, tier, status } from '../MockData';
import View from './View';
import './rel.css';

const keyValuePair = (data) => data.map(item => ({
    label: item,
    key: item,
    value: item
}))

const contentStyle = {

    height: '200px',
    color: '#fff',
    lineHeight: '60px',
    textAlign: 'Center',
    background: '#364d79',

};

class RealEstate extends Component {
    constructor(props) {
        super(props);
        this.state = {
            apartmentData: RealEstateData,
        }
    }


    renderCoursel = (images) => {

        return (
            <Carousel autoplay>
                {images.map(item => (
                    <div>
                        <h3 style={contentStyle}>

                            <img style={contentStyle} alt="example" src={item} />
                        </h3>
                    </div>
                ))}
            </Carousel>
        )

    }
    renderApartments = () => {
        const { apartmentData } = this.state;
        return apartmentData.map(item => (
            <Col span={6} style={{ margin: '3rem' }}>
                <Card
                    title={item.apartment_name}
                    bordered={false}
                    cover={this.renderCoursel(item.images)}
                >
                    <div className='box-text'>
                        <h2>Type: {item.tier}</h2>
                        <p>City: {item.city}</p>
                        <p>Status: {item.status}</p>
                        <p>Price: {item.price}</p>
                        <p>Contact: {item.contact}</p>
                    </div>
                    <View images={item.images} title={item.apartment_name} />
                </Card>
            </Col>
        ))
    }
    handleCitiesChange = (city) => {
        if (city === 'All') {
            this.setState({ apartmentData: RealEstateData })
        }
        else {
            const sanitizedData = RealEstateData.filter(item => item.city === city)
            this.setState({ apartmentData: sanitizedData })
        }
    }

    handleTiersChange = (tier) => {
        if (tier === 'All') {
            this.setState({ apartmentData: RealEstateData })
        }
        else {
            const sanitizedData = RealEstateData.filter(item => item.tier === tier)
            this.setState({ apartmentData: sanitizedData })
        }
    }


    handleStatusChange = (status) => {

        if (status === 'All') {
            this.setState({ apartmentData: RealEstateData })
        }
        else {
            const sanitizedData = RealEstateData.filter(item => item.status === status)
            this.setState({ apartmentData: sanitizedData })
        }
    }


    render() {
        
        return (

            <>
            <div style={{display:'flex'}}>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', margin: '2rem 2rem' }}>
                    <Select placeholder="Select Cities" style={{ width: 380 }}
                        options={[{
                            label: 'All',
                            key: 'All',
                            value: 'All',
                        },
                        ...keyValuePair(city),
                        ]} onChange={this.handleCitiesChange}

                    />
                    <Select placeholder="Select Types"
                        style={{ width: 320 }}

                        options={[{
                            label: 'All',
                            key: 'All',
                            value: 'All',
                        },
                        ...keyValuePair(tier),
                        ]} onChange={this.handleTiersChange}

                    />

                    <Select placeholder="Select Status"
                        style={{ width: 320 }}

                        options={[{
                            label: 'All',
                            key: 'All',
                            value: 'All',
                        },
                        ...keyValuePair(status),
                        ]} onChange={this.handleStatusChange}

                    />

                </div>
                <div className='image'>
                    <div style={{ padding: '30px', }}>
                        <Row gutter={16}>
                            {this.renderApartments()}
                        </Row>
                    </div>
                </div>,


            </>
        )
    }
}
export default RealEstate