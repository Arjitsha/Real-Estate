import React, { useState } from 'react';
import { Modal, Button } from 'antd';
import './rel.css';

function View(props) {
  const contentStyle = {
    
    height: '200px',
    color: '#fff',
    lineHeight: '60px',
    textAlign: 'Center',
    background: '#364d79',
    margin: '2rem'
  };
  const {images,title} = props;
    const [isModalVisible, setIsModalVisible] = useState(false);

  const showModal = () => {
    setIsModalVisible(true);
  };
  const renderImages = () => {
    return images.map(item=>(
      <img style={contentStyle} alt="example" src={item}  /> 
    ));
  };

  const handleOk = () => {
    setIsModalVisible(false);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
  };
    return (  
        <>
        <Button type="primary" onClick={showModal} >
          View
        </Button>
        
        <Modal title={title} visible={isModalVisible} onOk={handleOk} onCancel={handleCancel} footer={null}>
       {renderImages()}
        </Modal>
        
      </>
    );
}

export default View ;