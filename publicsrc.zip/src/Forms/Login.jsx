import React, { useState } from "react";
import { Alert } from "react-bootstrap";
import Mainpage from "../Main";
import './login.css';

function Login() {
  const [emaillog, setEmaillog] = useState(" ");
  const [passwordlog, setPasswordlog] = useState(" ");

  const [flag, setFlag] = useState(false);

  const [home, setHome] = useState(true);

  function handleLogin(e) {
    e.preventDefault();
    let pass = localStorage
      .getItem("Password")
      .replace(/"/g, "");
    let mail = localStorage.getItem("Email").replace(/"/g, "");
    

    if (!emaillog || !passwordlog) {
      setFlag(true);
      console.log("EMPTY");
    } else if (passwordlog !== pass || emaillog !== mail) {
      setFlag(true);
    } else {
      setHome(!Mainpage);
      setFlag(false);
    }
  }

  return (
    <div>
      {home ? (
        <form onSubmit={handleLogin}>
        
          <div className="form-group">
            <br></br>
          <h2>Log In</h2>
            <label></label>
            <input
              type="email"
              
              className="form-control"
              placeholder="Enter email"
              onChange={(event) => setEmaillog(event.target.value)}
            />
          </div>
          <br></br>
          <div className="form-group1">
            <label></label>
            <input
              type="password"
              
              className="form-control"
              placeholder="Enter password"
              onChange={(event) => setPasswordlog(event.target.value)}
            />
          </div>
          <br></br>

          <button  type="submit" className="prasad">
            Login
          </button>

          {flag && (
            <Alert color="primary" variant="warning">
              <div className="warn">Fill correct Info else keep trying.</div>
            </Alert>
          )}
        </form>
      ) : (
        <Mainpage />
      )}
    </div>
  );
}

export default Login;