import React, { useState } from "react";
import { Form, Alert } from "react-bootstrap";
import Login from "./Login";
import './login.css';



function Registration() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [phone, setPhone] = useState("");
  

  const [flag, setFlag] = useState(false);
  const [login, setLogin] = useState(true);
  


  function handleFormSubmit(e) {
    e.preventDefault();

    if (!name || !email || !password || !phone) {
      setFlag(true);
    } else {
      setFlag(false);
      localStorage.setItem("Email", JSON.stringify(email));
      localStorage.setItem(
        "Password",
        JSON.stringify(password)
      );
      console.log("Saved in Local Storage");

      setLogin(!login);
    }
  }

  function handleClick() {
    setLogin(!login);
  }
  



  return (
    <>
   
   <div className="css">
        <div>
          {" "}
          {login ? (
            <form onSubmit={handleFormSubmit}>
              

              <div className="form-group">
              <h2>Register Here</h2>
                <label></label>
                <input
                  type="text"
                  className="form-control"
                  placeholder="Enter Full Name"
                  name="name"
                  onChange={(event) => setName(event.target.value)}
                />
              </div>
<br></br>
              <div className="form-group">
                <label></label>
                <input
                  type="email"
                  className="form-control"
                  placeholder="Enter email"
                  onChange={(event) => setEmail(event.target.value)}
                />
              </div>
<br></br>
              <div className="form-group1">
                <label></label>
                <input
                  type="password"
                  className="form-control"
                  placeholder="Enter password"
                  onChange={(event) => setPassword(event.target.value)}
                />
              </div>
<br></br>
              <div className="form-group">
                <label></label>
                <input
                  type="Phone"
                  className="form-control"
                  placeholder="Enter contact no"
                  onChange={(event) => setPhone(event.target.value)}
                />
              </div>
<br></br>
              
              <button type="submit" className="prasad">
                Register
              </button>
              <div className="s1">
              <h2><p onClick={handleClick} className="forgot-password text-right">
               <a className="aaa" >Already registered?{" "}Log In</a>
                
              </p></h2>
              </div>
              {flag && (
                
                <Alert color="primary" variant="danger" className="form-group">
                 <p> I got it you are in hurry! But every Field is important!</p>
                </Alert>
              )}
            </form>
            
          ) : (
            <Login />
          )}
        </div>
        
        
        </div>

    </>
  );
}

export default Registration;