import React from 'react'
//import Best from './components/best/Best'
//import Hero from './components/hero/Hero'
//import Navbar from './components/navbar/Navbar'
//import Footer from './components/footer/Footer'
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Registration from './Forms/Registration'
import Mainpage from './Main';
import 'antd/dist/antd.css'; 
import RealEstate from './Pages/RealEstate';
import View from './Pages/View';
import Login from './Forms/Login';



function App(props) {
  console.log(props)
  return (

    <div>

            <Routes>
            <Route path="/" element={<Registration />} />
            <Route path="/registraion" element={<Login />} />
        <Route path="/login" element={<Mainpage  />} />
        <Route path="/mainpage" element={<Mainpage  />} />
        <Route path="/realEstate" element={<RealEstate />} />
      </Routes>

        {/* <Mainpage/> */}
   {/* <Registration/> */}

   {/* <RealEstate/> */}

   {/* <View/> */}
   
   
  

   
   </div>
   
   

    
  );
}

export default App;
