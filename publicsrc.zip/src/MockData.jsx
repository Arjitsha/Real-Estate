export const RealEstateData = [
    {
        id: 1,
        apartment_name: 'Daisy Apartments',
        tier: '1 BHK',
        city: 'Pune',
        status: 'Rent',
        price: 'Rs-15000',
        contact:'9876545678',
        images: [
           'https://media.istockphoto.com/photos/exterior-view-of-modern-apartment-building-offering-luxury-rental-in-picture-id1322575582?b=1&k=20&m=1322575582&s=170667a&w=0&h=bGCtLpgCEorQuVdW2lbWguNZHcOGPePSwDibgbgyh0U=',
          'https://static.zingyhomes.com/projectImages/cache/2f/7d/2f7de970e4811d49255b609460e58c13.jpg',
           'https://media.designcafe.com/wp-content/uploads/2020/09/26182253/u-shaped-kitchen-for-cozy-3bhk-house-design.jpg',
           'https://images.unsplash.com/photo-1598928636135-d146006ff4be?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8YmVkcm9vbXxlbnwwfHwwfHw%3D&w=1000&q=80'
        ]

    },
    {
        id: 2,
        apartment_name: 'Green House',
        tier: '1 BHK',
        city: 'Bangalore',
        status: 'Rent',
        price: 'Rs-18000',
        contact:'7896543289',
        images: [
            'https://www.chennaiproperties.in/projectsgallery/3265/gallery/DRA_Delite_1.jpg',
            'https://img.gtsstatic.net/reno/imagereader.aspx?imageurl=https%3A%2F%2Fsir.azureedge.net%2F1103i215%2Fgq0my3dyaamym0asse94tchwr1i215&option=N&h=472&permitphotoenlargement=false',
            'https://classicinfrahomesinterior.com/wp-content/uploads/2022/01/modular-kitchen-design-for-a-two-bedroom-apartment.jpg',
             'https://housefrey.com/wp-content/uploads/2021/12/Two-Colour-Combinations-For-Bedroom-Walls.jpg'
             
        ]
    },
    {
        id: 3,
        apartment_name: 'Peace Apartments',
        tier: '1 BHK',
        city: 'Mumbai',
        status: 'Sell',
        price: 'Rs-20000',
        contact:'9786543129',
        images: [
            'https://img.staticmb.com/mbimages/project/Photo_h300_w450/2019/12/11/Project-Photo-2-Crown-Navi-Mumbai-5128841_600_800_300_450.jpg',
            'https://vasupujya.com/wp-content/uploads/2021/01/Home-decor-tips-for-1-BHK.jpg',
            'https://media.designcafe.com/wp-content/uploads/2021/04/06180831/elegant-1bhk-home-design-with-l-shaped-modular-kitchen-in-light-wood.jpg',
            'https://media.designcafe.com/wp-content/uploads/2021/03/06173238/1bhk-apartment-bedroom-design-with-classy-interiors.jpg'
        ]
    },
    {
        id: 4,
        apartment_name: 'Pearl Homes',
        tier: '1 BHK',
        city: 'Delhi',
        status: 'Buy',
        price: 'Rs-11000',
        contact:'7654890400',
        images: [
            'https://kkhomedesign.com/wp-content/uploads/2020/09/25x18-Feet-Small-House-Design-795x385.jpg' ,
            'https://media.designcafe.com/wp-content/uploads/2021/03/06121551/latest-living-room-design-designed-in-1bhk-house-design.jpg', 
            'https://media.designcafe.com/wp-content/uploads/2021/03/06173354/dual-colour-tone-kitchen-designed-in-1bhk-apartment-with-hexagonal-tiled-backsplash.jpg',
            'https://www.dnkinteriordesigners.in/images/location/interior-designer-thane.jpg'
        ]
    },
    {
        id: 5,
        apartment_name:'Royal View Apartment',
        tier: '1 BHK',
        city: 'Bangalore',
        status: 'Buy',
        price: 'Rs-24000',
        contact:'7658905411',
        images: [
          'https://mediacdn.99acres.com/media1/16901/7/338027914M-1641560100542.jpeg',
          'https://www.zingyhomes.com/projectImages/cache/de/15/de152d65cf99605401ca2e7cc2a1e1c0.jpg',
          'https://sp-ao.shortpixel.ai/client/to_webp,q_glossy,ret_img/https://classicinfrahomesinterior.com/wp-content/uploads/2022/01/A-well-designed-1BHK-apartment-with-a-wide-range-of-materials-and-finishes.-1.jpg',
          'https://is1-2.housingcdn.com/01c16c28/38ff69d2a4f6742ea3e050d8198561ed/v0/medium/1_bhk_apartment-for-sale-malsi-Dehradun-bedroom.jpg'
        ]
    },
    {
        id: 6,
        apartment_name: 'Homely Villas',
        tier: '1 BHK',
        city: 'Chennai',
        status: 'Rent',
        price: 'Rs-18000',
        contact:'7766098657',
        images: [
            'https://img.staticmb.com/mbimages/project/Photo_h310_w462/2020/02/13/Project-Photo-17-Mahaveer-Northscape-Bangalore-5133671_563_1000_310_462.jpg',
            'http://www.citadilinterior.com/wp-content/uploads/2020/06/citadil-Interior-1-bhk-interior-design-idesa.jpg',
            'https://images.homify.com/images/a_0,c_fill,f_auto,h_900,q_auto,w_1920/v1484908333/p/photo/image/1787462/DSC_0268/modern-kitchen-photos-in-grey-by-design-arc-interiors-interior-design-company.jpg',
            'https://mediacdn.99acres.com/media1/17388/7/347767070M-1646369165567.jpg'
        ]
    },
    {
        id: 7,
        apartment_name: 'Elite Complex',
        tier: '1 BHK',
        city: 'Bhubneshwar',
        status: 'Rent',
        price: 'Rs-14000',
        contact:'8876543211',
        images: [
            'https://is1-2.housingcdn.com/01c16c28/54bd3e632f82162874b7014443d98310/v0/fs/3_bhk_apartment-for-sale-dombivli_east-Thane-building_view.jpg',
            'https://www.zingyhomes.com/projectImages/cache/eb/09/eb09c22113c1901cb371a8375e1cbf17.jpg',
            'https://i.pinimg.com/originals/22/1f/5e/221f5e60afe399078406e9522a47e755.jpg',
            'https://mediacdn.99acres.com/media1/17513/0/350260318M-1647515947915.jpg'
        ]
    },
    {
        id: 8,
        apartment_name: 'Maitree Complex',
        tier: '2 BHK',
        city: 'Jaipur',
        status: 'Buy',
        price: 'Rs-2400000',
        contact:'9870012311',
        images: [
            `https://i.pinimg.com/originals/97/7a/a0/977aa07305a0e5c753819f0efdad72f3.jpg`,
            `https://i.pinimg.com/originals/c2/1b/03/c21b03502be2c430de2e3b0a3e3318cb.jpg`,
            `https://www.furnitureacademy.com/wp-content/uploads/2018/04/Living-Room-Interior-Design.jpg`,
             `https://cdn.mos.cms.futurecdn.net/JbyzkVoCjeDXp9r6ewHSVB-768-80.jpg`
            
        ]
    },
    {
        id: 9,
        apartment_name: 'Safe Homes',
        tier: '2 BHK',
        city: 'Bangalore',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9089076541',
        images: [
        `https://thumbor.forbes.com/thumbor/fit-in/900x510/https://www.forbes.com/advisor/wp-content/uploads/2021/03/featured-small-kitchen-remodel-cost.jpg`,
        `https://www.thespruce.com/thmb/jq8TIaI1cHj_kyG1iaexQWHoGp0=/5127x2884/smart/filters:no_upscale()/bed-and-fireplace-in-luxury-bedroom-748316169-37b1062605034b23ab6d193be9c58ef6.jpg`,
        `https://www.thespruce.com/thmb/rmDEwUoAgwucuusBRvFoE4JBc0o=/4000x2250/smart/filters:no_upscale()/master-bedroom-in-new-luxury-home-with-chandelier-and-large-bank-of-windows-with-view-of-trees-1222623844-212940f4f89e4b69b6ce56fd968e9351.jpg`,
         `https://homedesignlover.com/wp-content/uploads/2013/10/long-living.jpg`
        ]
    },
    {
        id: 10,
        apartment_name: 'Green House Mansion',
        tier: '2 BHK',
        city: 'Bangalore',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9081123321',
        images: [
            `https://www.thespruce.com/thmb/9zdyLzPobCbaJrCfue4JR-xe6Ps=/2075x1167/smart/filters:no_upscale()/living-room-dos-and-donts-2213467-hero-da82a4643bc84d669a0a34f64e60beb1.jpg`,
             `https://i.pinimg.com/736x/63/d4/66/63d46604722ef7ea9d3631a54beff599.jpg`,
             `http://cdn.home-designing.com/wp-content/uploads/2014/09/bachelor-bedroom.jpeg`,
             `https://media.architecturaldigest.com/photos/5e83b9325d64790008080e81/16:9/w_2560%2Cc_limit/GettyImages-960874986.jpg`
        ]
    },
    {
        id:11,
        apartment_name: 'Sunset Villas',
        tier: '2 BHK',
        city: 'Chennai',
        status: 'Rent',
        price: 'Rs-21000',
        contact:'8790000123',
        images: [
            `http://cdn.home-designing.com/wp-content/uploads/2014/09/modern-feminine-bedroom.jpeg`,
            `http://cdn.home-designing.com/wp-content/uploads/2014/09/sleek-bedroom-design1.jpeg`,
            `https://www.oppeinhome.com/upload//images/ueditor/20210820/Kitchen-storage-plan.jpg`,
             `https://www.thewowdecor.com/wp-content/uploads/2021/08/SMALL-LIVING-ROOM1.jpg`
        ]
    },
    {
        id: 12,
        apartment_name: 'Daisy Apartments',
        tier: '2 BHK',
        city: 'Pune',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9081123321',
        images: [
            `https://i.pinimg.com/736x/f4/d8/da/f4d8da0bda9e41f24f3f04d8704fc085--upholstered-bedroom-ideas-master-bedroom-design.jpg`,
             `https://cdn-bnokp.nitrocdn.com/QNoeDwCprhACHQcnEmHgXDhDpbEOlRHH/assets/static/optimized/rev-2b3fe8f/online-decorating/wp-content/uploads/2021/03/Calming-gray-master-bedroom-design.jpeg`,
             `https://buildingandinteriors.com/wp-content/uploads/2020/10/feature-image-2.jpg`,
             `https://www.dea5.net/wp-content/uploads/Our-Guide-To-Keeping-Your-Home-Clean-This-Winter.jpg`

        ]
    },
    {
        id: 13,
        apartment_name: 'Shine Apartments',
        tier: '2 BHK',
        city: 'Mumbai',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9081123321',
        images: [
              `https://modsy-prod.imgix.net/rimg/tr_c4df3e38-8a1e-4f5e-bd70-34216c5c7444_786849_1_elsie_userview_2.jpg?auto=compress%2Cformat&fit=clip`,
              `https://mir-s3-cdn-cf.behance.net/project_modules/fs/d8a461118548267.608b0b4e89e21.jpg`,
              `https://www.tecnografica.net/data/content/info/Yasmine-ibrahem-master-bedroom-aura-wallpaper-01.jpg`,
              `https://res.cloudinary.com/urbanclap/image/upload/t_medium_res_portfolio_medium/images/5a5e3a1ec3ff555f004391c9/1516127962608-7b922c0b4e12bc0f85ad2f4be073c3d3.undefined`
        ]
    },
    {
        id: 14,
        apartment_name: 'Pearl Homes',
        tier: '2 BHK',
        city: 'Jaipur',
        status: 'Rent',
        price: 'Rs-17000',
        contact:'9081123321',
        images: [
            `https://www.elements4kitchens.com/img/Kitchen%20Image%201.jpg`,
            `https://www.mydomaine.com/thmb/dlBxrCIOjTncfozsqgvbRAIRD58=/2500x1406/smart/filters:no_upscale()/DesignbyEmilyHendersonDesignandPhotobySaraLigorria-Tramp_654-b8122ec9f66b4c69a068859958d8db37-c782973dc46540a39c223f89d6a01ba1.jpeg`,
            `https://onehundrededition.com/wp-content/uploads/2021/05/100-Moscow-10-High-End-Residential-Projects-in-Moscow-6.jpg`,
            `https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/bedroom-9-1577988897.jpg?crop=0.998xw:0.385xh;0.00160xw,0.253xh&resize=1200:*`,
            `https://www.ylighting.com/blog/wp-content/uploads/2020/03/Luna-90-Inch-Sofa-by-TrueModern.jpg`
        ]
    },
    {
        id: 15,
        apartment_name: 'Sweet Villas',
        tier: '2 BHK',
        city: 'Pune',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9081123321',
        images: [
            `https://www3.pictures.lonny.com/mp/DctkRlTDjDMx.jpg`,
            `https://www.howdens.com/-/media/howdens/assets/clh_asset_products/clh_asset_levela_108418/clh_asset_levelb_110114/clh_asset_levelc_25285963/ass_25415393.jpg`,
            `https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/2-marco-ricca-1544213096.jpg?crop=1.00xw:0.756xh;0,0.130xh&resize=480:*`,
             `https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/green-bedroom-5-1554842194.jpg`,
             `https://cdn.apartmenttherapy.info/image/upload/f_jpg,q_auto:eco,c_fill,g_auto,w_1500,ar_16:9/at%2Farchive%2F479458640eca110b5a4be0f7d758419b395dc2fa`
        ]
    },
    {
        id: 16,
        apartment_name: 'Happy Homes',
        tier: '2 BHK',
        city: 'Bangalore',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9081123321',
        images: [
            `https://cdn.mos.cms.futurecdn.net/ePJAM8bWd9yEzNbTGWu6P8.jpg`,
            `https://media.architecturaldigest.com/photos/58066f0c13027a4c2910537f/16:9/w_2580,c_limit/modern-living-rooms-27.jpg`,
            `http://cdn.home-designing.com/wp-content/uploads/2019/10/mint-green-bedroom.jpg`,
            `https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/end-of-bed-05-1502721659.jpg?crop=1.00xw:0.753xh;0,0.247xh&resize=480:*`,
            `https://imagesvc.meredithcorp.io/v3/mm/image?q=60&c=sc&poi=%5B480%2C286%5D&w=1000&h=500&url=https%3A%2F%2Fstatic.onecms.io%2Fwp-content%2Fuploads%2Fsites%2F34%2F2021%2F10%2F20%2Flarge-white-countertop-kitchen-island-1021.jpeg`
        ]
    },
    {
        id: 17,
        apartment_name: 'Sunshine Place',
        tier: '2 BHK',
        city: 'Bangalore',
        status: 'Rent',
        price: 'Rs-28000',
        contact:'9081123321',
        images: [
            `https://w2.chabad.org/media/images/1056/xoJL10560372.jpg?_i=_n504BC99DD0473598AAE3BCDC5D75568D`,
            `https://i.pinimg.com/736x/d8/c0/4e/d8c04ec61ae36b681f56f61c17a7c416.jpg`,
            `https://i.pinimg.com/736x/33/49/01/3349012e02f818c6255c867816c610a0.jpg`,
            `https://blog.modsy.com/wp-content/uploads/2020/01/R678247_D2_5-1.jpg?width=1200`
        
        ]
    },
    {
        id: 18,
        apartment_name: 'Sunrise Villas',
        tier: '3 BHK',
        city: 'Chennai',
        status: 'Buy',
        price: 'Rs-40000000',
        contact:'8780123123',
        images: [  'https://images.unsplash.com/photo-1612637968894-660373e23b03?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8YXBhcnRtZW50JTIwYnVpbGRpbmd8ZW58MHx8MHx8&w=1000&q=80',
                  'https://images.unsplash.com/photo-1567767292278-a4f21aa2d36e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTR8fGxpdmluZyUyMHJvb218ZW58MHx8MHx8&w=1000&q=80',
                  'https://images.unsplash.com/photo-1588854337236-6889d631faa8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8N3x8c21hcnQlMjBraXRjaGVufGVufDB8fDB8fA%3D%3D&w=1000&q=80',
                  'https://images.unsplash.com/photo-1617104678098-de229db51175?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8YmVkcm9vbXN8ZW58MHx8MHx8&w=1000&q=80',
                  'https://images.unsplash.com/photo-1616486029423-aaa4789e8c9a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjF8fGJlZHJvb218ZW58MHx8MHx8&w=1000&q=80',
                  `https://media.designcafe.com/wp-content/uploads/2020/09/26152803/master-bedroom-design-in-3-bhk-interior-design.jpg`
                  
              
        ]
    },
   
    {
        id: 19,
        apartment_name: 'Green House Mansion',
        tier: '3 BHK',
        city: 'Bangalore',
        status: 'Rent',
        price: 'Rs-30000',
        contact:'9801231209',
        images: [
          'https://modern-villas.com/wp-content/uploads/2017/10/Flying-House-Modern-Villa-Design-3.jpg',
          'https://goflatpacks.com.au/wp-content/uploads/2017/08/goflatpacks-blog-image.jpg',
          'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1000&q=80',
          'https://homifind.files.wordpress.com/2019/02/3568bb5e-3f47-4f1c-a690-6cfd58a55867.jpg',
          'https://cdn.home-designing.com/wp-content/uploads/2014/02/3-Travel-theme-kids-bedroom.jpg',
          'https://www.wabisabiliving.com/assets/public/images/id-interiors-reFGz40ok8E-unsplash.jpg'
        ]
    },
    {
        id: 20,
        apartment_name: 'Shine Apartments',
        tier: '3 BHK',
        city: 'Mumbai',
        status: 'Sell',
        price: 'Rs-50000000',
        contact:'7755120096',
        images: [
            'https://property-media.realgeeks.com/1/7050494cea8e98f7b64735a7f000ce6f.jpg',
            'https://media.istockphoto.com/photos/modern-apartment-living-room-interior-picture-id1314299383?b=1&k=20&m=1314299383&s=170667a&w=0&h=ZaWlAGU93wqAZSzTc3juxkDQpR5MMSvCA8PKelJmoUE=',
            'https://images.unsplash.com/photo-1613685703237-6628de38ddb7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTV8fGJlZCUyMHJvb218ZW58MHx8MHx8&w=1000&q=80',
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ4vKXxNzutFiuZczE4yb66mtMMaZgFrMrHep0wtfxS8wLN4kDdqh8Socl955tNXSvz4-E&usqp=CAU',
            'https://cdn.decoist.com/wp-content/uploads/2013/05/Stylish-girls-bedroom-in-pink-and-silver.jpg',
            'https://images.squarespace-cdn.com/content/v1/5b5b0648365f02c639710485/1535421442362-M5IKFEUW3LP0W1UDAG7R/High-resolution-kitchen-1.jpg?format=2500w'
        ]
    },
    {
        id: 21,
        apartment_name: 'Dream Palace',
        tier: '3 BHK',
        city: 'Mumbai',
        status: 'Sell',
        price: 'Rs-10000000',
        contact:'9876543210',
        images: [
            'https://www.housedesignerbuilder.com/uploads/1/3/5/6/13561331/8528935.jpg',
            'https://media.istockphoto.com/photos/modern-holiday-villa-with-beach-view-picture-id1315916915?b=1&k=20&m=1315916915&s=170667a&w=0&h=hAlIUwnsBGxjNmrGXerg6HkYaKcTFH6KF7mO8EEbPoM=',
            'https://images.unsplash.com/photo-1560448205-4d9b3e6bb6db?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTd8fHJvb218ZW58MHx8MHx8&w=1000&q=80',
            'https://nimvo.com/wp-content/uploads/2017/07/Master-bedroom-wood-floor.jpg',
            'https://homedesignlover.com/wp-content/uploads/2016/04/modern-kids-bedroom.jpg',
            'https://www.crescent-builders.com/blog/wp-content/uploads/2020/06/sidekix-media-LPk9luwemT0-unsplash-1024x683.jpg'
        ]
    },
    {
        id: 22,
        apartment_name: 'Holly Villa',
        tier: '3 BHK',
        city: 'Mumbai',
        status: 'Sell',
        price: 'Rs-7000000',
        contact:'9876543210',
        images: [
            'https://miro.medium.com/max/1400/1*hAmF9wlpMPKo_MYg1qcT6w.jpeg',
            'https://media.istockphoto.com/photos/living-room-with-sofa-and-modern-kitchen-on-background-picture-id1153707356?b=1&k=20&m=1153707356&s=170667a&w=0&h=Bz54kJdaKxNtvFomvIW6n_RTw2lXctA1afJ1qfRIGsI=',
            'https://iconiclife.com/wp-content/uploads/2020/11/IMI-Designs-winter-2020-ICONIC-HAUS-master-bedroom.jpg',
            'https://st.hzcdn.com/simgs/pictures/bedrooms/overland-park-remodel-picture-kc-img~e3b111610c475069_14-7523-1-df2022d.jpg',
            'https://i.ytimg.com/vi/fIR2ENIOSsA/maxresdefault.jpg',
            'https://media.istockphoto.com/photos/domestic-kitchen-interior-picture-id957053734?k=20&m=957053734&s=170667a&w=0&h=DgDYnG1dBUmUOZpGhNgMzQlZSzwjelktick9oUY67IQ='
        ]
    },
    {
        id: 23,
        apartment_name: 'Pearl Homes',
        tier: '3 BHK',
        city: 'Jaipur',
        status: 'Buy',
        price: 'Rs-1000000',
        contact:'9081123321',
        images: [
            'https://is1-2.housingcdn.com/4f2250e8/3288b6cec47a1b012a0ae66ec22559c1/v0/medium.jpeg',
            'https://nhs-dynamic.secure.footprint.net/Images/Homes/Smith4827/45899736-200911.png?w=1000&quality=20',
            'https://images.unsplash.com/photo-1598928636135-d146006ff4be?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Nnx8YmVkcm9vbXxlbnwwfHwwfHw%3D&w=1000&q=80',
            'https://media.istockphoto.com/photos/cottage-interior-picture-id1074669924?b=1&k=20&m=1074669924&s=170667a&w=0&h=Np9LJhYpjQqQO99nLDNTaFTBbVueYQiA5eLv_fRPcZY=',
            'https://cdn.home-designing.com/wp-content/uploads/2014/02/12-Blue-teenagers-room.jpg',
            'https://decoruss.com/wp-content/uploads/2020/09/sidekix-media-_IAZoJ6X-1A-unsplash-640x427.jpg'
           
        ]
    },
    {
        id: 24,
        apartment_name: 'The Haven',
        tier: '3 BHK',
        city: 'Mumbai',
        status: 'Sell',
        price: 'Rs-50000000',
        contact:'9081123321',
        images: [
            'https://media.istockphoto.com/photos/lowrise-houses-mixeduse-urban-multifamily-residential-district-area-picture-id1306005048?b=1&k=20&m=1306005048&s=170667a&w=0&h=_cAIO-lmINGZDL7v4lALgkS1PNTzJjiJuHeAJTt-JR4=',
            'https://images.unsplash.com/photo-1602872030548-7bf4aaf8c06d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTJ8fHdhcm0lMjByb29tfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
            'https://www.eastwoodhomes.com/content/cms/blog/104%20Bushney%20Loop%20Mooresville-small-025-24-Owners%20Bedroom-666x445-72dpi.jpg',
            'https://media.istockphoto.com/photos/cozy-bedroom-interior-picture-id1053944358?b=1&k=20&m=1053944358&s=170667a&w=0&h=IZuQgCDwSRB0zC4asd0P8DL0v-jnPF8pFtCtzuvGYVE=',
            'https://st.hzcdn.com/simgs/pictures/kids-rooms/pretty-in-pink-little-girls-bedroom-cheryl-hucks-interior-designs-img~490133580fb8022a_4-0272-1-200b886.jpg',
            'https://5.imimg.com/data5/SELLER/Default/2021/9/KG/MH/VJ/111398542/modular-kitchens-500x500.jpg'
        ]
    },
    {
        id: 25,
        apartment_name: 'Lotus Palace',
        tier: '4 BHK',
        city: 'Bangalore',
        status: 'Buy',
        price: 'Rs-5560087',
        contact:'9081123321',
        images: [
            'https://tripsvilla.com/wp-content/uploads/2021/06/4bhk-skye-villa-goa-nerul-tripsvilla.webp',
            'https://is1-3.housingcdn.com/01c16c28/8e72ea6e2641f34cf5569af90638c509/v0/large/4_bhk_apartment-for-sale-egatoor-Chennai-living_room.jpg',
            'https://images.unsplash.com/photo-1602028915047-37269d1a73f7?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8a2l0Y2hlbiUyMGRlc2lnbnxlbnwwfHwwfHw%3D&w=1000&q=80',
            'https://media.istockphoto.com/photos/modern-master-bedroom-picture-id858622908?k=20&m=858622908&s=612x612&w=0&h=0diN3r1q6PLW4LG0QpQPeZQ0bMNt_CT8jM3EB6qtszU=',
            'https://www.nerolac.com/sites/default/files/styles/1489_663/public/Banner.jpg?itok=RHk-JEaN',
            'https://www.zadinteriors.com/blog/wp-content/uploads/2021/08/21.-Banana-Yellow-and-Berry-Blue-Bedroom-Color.jpg',
            'https://bloggerslogger.com/wp-content/uploads/2021/07/Two-Colour-Combination-For-Bedroom-Walls-10-1200x900.jpg'
            
        ]
    },
    {
        id: 26,
        apartment_name: 'Star World',
        tier: '4 BHK',
        city: 'Chennai',
        status: 'Sell',
        price: 'Rs-8956000',
        contact:'9081123321',
        images: [
            'https://mediacdn.99acres.com/media1/17113/13/342273406M-1643708064667.jpg',
            'https://is1-2.housingcdn.com/01c16c28/01b722e0789d69423d2d6aa86d72ea55/v0/fs/4_bhk_apartment-for-sale-sector_82a-Gurgaon-hall.jpg',
            'https://www.irishtimes.com/polopoly_fs/1.4211142!/image/image.jpg_gen/derivatives/landscape_620/image.jpg',
            'https://i.pinimg.com/originals/c5/0f/09/c50f095682bc8cdcff511d46aaddf8db.jpg',
            'https://www.nipponpaint.co.in/wp-content/uploads/2019/04/Light-blue-and-Radiant-Yellow-paint-colour-combinations-1024x640.jpg',
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThzmRYctLDbUjRwqUXASQCFzcS4Pxw1mRKW6snyFwRkmQgKDyfPRJjrIt3AFP5sd80Oz0&usqp=CAU',
            'https://www.homelane.com/blog/wp-content/uploads/2017/04/shutterstock_728436457.jpg'
        ]
    },
    {
        id: 27,
        apartment_name: 'White Palace',
        tier: '4 BHK',
        city: 'Pune',
        status: 'Sell',
        price: 'Rs-9855600',
        contact:'9081123321',
        images: [
            'https://st.hzcdn.com/simgs/pictures/exteriors/modern-mansion-shay-velich-architectural-and-interior-photographer-img~caa1b29f06d607fd_4-1190-1-45ac54b.jpg',
            'https://is1-3.housingcdn.com/01c16c28/7d7394831d8437b727ddce4bf9d94c22/v0/fs/6_bhk_apartment-for-sale-andheri_west-Mumbai-living_room.jpg',
            'https://images.unsplash.com/photo-1539922980492-38f6673af8dd?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bW9kdWxhciUyMGtpdGNoZW58ZW58MHx8MHx8&w=1000&q=80',
            'https://images.unsplash.com/photo-1574873215043-44119461cb3b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTl8fGJlZHJvb21zfGVufDB8fDB8fA%3D%3D&w=1000&q=80',
            'https://tajindiaresorts.com/ImageBulk/637080887897190907wooden-furniture-bedroom-with-beach-view.jpg',
            'https://images.unsplash.com/photo-1611892440504-42a792e24d32?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDV8fHxlbnwwfHx8fA%3D%3D&w=1000&q=80',
            'https://st.hzcdn.com/simgs/pictures/bedrooms/fort-morgan-beach-home-riegler-photography-img~4ce174510150b6d1_14-0538-1-22c595d.jpg'
        ]
    },
    {
        id: 28,
        apartment_name: 'Gold Desert',
        tier: '4 BHK',
        city: 'Bhubneshwar',
        status: 'Sell',
        price: 'Rs-87954600',
        contact:'9081123321',
        images: [
            'https://3.imimg.com/data3/WJ/PG/MY-12040296/individual-villa-ongoing-projects-500x500.png',
            'https://i.pinimg.com/736x/51/be/75/51be7561805128c45853f3e5180ddc63.jpg',
            'https://images.squarespace-cdn.com/content/v1/5df7de84e82a2910e9e24e0c/1603152300468-40SLZPVNUCGL32CA6VKW/13_KitchenOverall.jpg?format=1500w',
            'https://www.13004decor.com.au/DecorBlindsCurtains/media/Images/Inspiration/Bedrooms-new/bedroom-7.jpg',
            'https://www.fairhavenhomes.com.au/cms/content/uploads/2021/02/clovelly-225-single-storey-display-waterfordrise-estate-fairhaven-homes-bedroom-1.jpg',
            'https://st.hzcdn.com/simgs/pictures/bedrooms/perth-showhome-zac-and-zac-photography-img~24b1112804be8c19_4-3924-1-bb05f85.jpg',
            'https://images.unsplash.com/photo-1560448205-4d9b3e6bb6db?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTd8fHJvb218ZW58MHx8MHx8&w=1000&q=80'
        ]
    },
    {
        id: 29,
        apartment_name: 'Dreamsville',
        tier: '4 BHK',
        city: 'Delhi',
        status: 'Rent',
        price: 'Rs-9875600',
        contact:'9081123321',
        images: [
            'https://mediacdn.99acres.com/media1/13667/3/273343670M-1610635462865.jpg',
            'https://i.pinimg.com/736x/60/0b/32/600b32fb0f28e16ba8d2fe1fea513b3e.jpg',
            'https://cdn.nar.realtor/sites/default/files/styles/inline_paragraph_image/public/SSS_trendingbystate_zac-gudakov-ZtQBm7Q1XWg-unsplash.jpg?itok=zGwsYg6c',
            'https://stylemasterhomes.com.au/wp-content/uploads/2015/04/21.jpg',
            'https://st.hzcdn.com/simgs/pictures/bedrooms/display-home-fortitude-metricon-img~a8116c170c12ea3e_4-6658-1-22b5d35.jpg',
            'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNYNxAnoiP5tVOInQYAe7cYtwPkxfHc3oE2RqY4v1wCltAq9xKpKFlmZzEBPAvjAmeO3Q&usqp=CAU',
            'https://www.ventura-homes.com.au/wp-content/uploads/2014/08/ventura1.gif'
        ]
    },
    {
        id: 30,
        apartment_name: 'BEST Apartments',
        tier: '4 BHK',
        city: 'Pune',
        status: 'Buy',
        price: 'Rs-87905600',
        contact:'9081123321',
        images: [
            'https://mediacdn.99acres.com/media1/11956/6/239126423M-1605946654920.jpeg',
            'https://www.asiaholidayretreats.com/wp-content/uploads/2019/03/Villa-Kubu-Premium-Spa-One-Bedroom-Living-Room-1-Seminyak-Bali-1360x660.jpg',
            'https://www.awesomedecors.us/wp-content/uploads/2019/05/kitchen-green.jpg',
            'https://media.istockphoto.com/photos/luxury-modern-bedroom-interior-at-night-picture-id1318363878?b=1&k=20&m=1318363878&s=170667a&w=0&h=N8ZrWT759EQeCpSmLsh2j08HBPEtMDBr-h1r6d4CDQk=',
            'https://images.unsplash.com/photo-1595526051245-4506e0005bd0?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDE0fHx8ZW58MHx8fHw%3D&w=1000&q=80',
            'https://media.aws.gjgardner.com.au/images/36937/36937-big.jpg',
            'https://st.hzcdn.com/simgs/pictures/bedrooms/display-home-savannah-41rf-metricon-img~14614ceb07326c77_4-4997-1-f144b5a.jpg'
        ]
    },
    {
        id: 31,
        apartment_name: 'Crystal Cottage',
        tier: '4 BHK',
        city: 'Mumbai',
        status: 'Buy',
        price: 'Rs-1987600',
        contact:'9081123321',
        images: [
            'https://www.cascadebuildtech.com/wp-content/uploads/2019/12/JLPL-Falcon-View-4BHK-Flats-For-Sale-in-Mohali-cascade-buildtech-1200x630.jpg',
            'https://www.storynorth.com/wp-content/uploads/2021/06/image-65.png',
            'https://www.residencestyle.com/wp-content/uploads/2019/01/Modular-Kitchen.jpg',
            'https://images.unsplash.com/photo-1560185893-a55cbc8c57e8?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MXx8bWFzdGVyJTIwYmVkcm9vbXxlbnwwfHwwfHw%3D&w=1000&q=80',
            'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTV8fGJlZHJvb218ZW58MHx8MHx8&w=1000&q=80',
            'https://antonovich-design.ae/uploads/page/2022/2/antonovich-design-thumb2022oHuQhJVyAAL4.jpeg',
            'https://media.istockphoto.com/photos/scandinavian-bedroom-interior-stock-photo-picture-id1282322973?k=20&m=1282322973&s=170667a&w=0&h=4RlJuptMeKX9O1efo-RwpmE_Pn_2NQeIB1DnYOXFrl0='
        ]
    },
]

export const city = [
    'Bangalore',
    'Chennai',
    'Jaipur',
    'Pune',
    'Mumbai',
    'Delhi',
    
]


export const tier = [
    '1 BHK',
    '2 BHK',
    '3 BHK',
    '4 BHK'
]

export const status = [
    'Buy',
    'Rent',
    'Sell'
    
]